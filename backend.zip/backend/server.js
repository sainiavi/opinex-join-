import express from "express";
import cors from "cors";
import sqlite3 from "sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;
const ALLOWED_ORIGIN = process.env.CORS_ORIGIN || "http://localhost:5173";

app.use(cors({ origin: ALLOWED_ORIGIN }));
app.use(express.json());

const dbPath = path.join(__dirname, "data", "waitlist.db");
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(
    "CREATE TABLE IF NOT EXISTS waitlist (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, created_at TEXT)"
  );
});

app.post("/api/waitlist", (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  if (!email || !email.includes("@")) {
    return res.status(400).json({ ok: false, error: "Invalid email" });
  }

  const createdAt = new Date().toISOString();
  const stmt = "INSERT OR IGNORE INTO waitlist (email, created_at) VALUES (?, ?)";
  db.run(stmt, [email, createdAt], function onInsert(err) {
    if (err) {
      return res.status(500).json({ ok: false, error: "Database error" });
    }
    return res.json({ ok: true, inserted: this.changes === 1 });
  });
});

app.listen(PORT, () => {
  console.log(`Waitlist backend running on port ${PORT}`);
});
